Thank you for using JScharts (jscharts.com)
Please read the following note before starting


JS Charts is available free for both non-commercial and commercial purposes. 


License Note
This license does NOT allow you to distribute, resell or embed/enclose JS Charts into another distribution pack/application which outputs similar content that can be used by third parties. 
To get the source codes, special customizations licenses please contact our sales department at sales [at] jumpeyecomponents.com


Support Note
No support is included within the JSCharts free component, however we encourage you to use JSCharts forum for any issues you encounter.


Start using the JSCharts Note
For details, please read the Jscharts.pdf manual.


For more details please visit our website www.jscharts.com